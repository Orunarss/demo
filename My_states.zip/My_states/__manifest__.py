
# -*- coding: utf-8 -*-

{
    "name" : "Ottos super nice module",
    "version" : "1.0",
    "author" : "Otto the bestest developer ever",
    'category': 'Localization',
    "description": """
TToi t'es bon qu'à planer
Ouais je sens t'as l'seum, j'ai l'avocat
Entre nous y'a un fossé
Toi t'es bon qu'à faire la mala
Bébé fait du sale, allô allô allô
Million d'dollars, bébé tu vaux ça
Bébé fait du sale, allô allô allô
Million d'dollars, bébé tu vaux ça
J'suis gang, hors game
Boy ne joue pas, bang bang bang
J'suis gang, hors game
Boy ne joue pas, bang bang bang
Blah blah blah d'la pookie
Ferme la porte, t'as la pookie dans l'side
Blah blah blah d'la pookie
Ferme la porte, t'as la pookie dans l'sas
Pookie, pook-pook-pookie
Ferme, ferme la porte, t'as la pookie dans l'side
Pookie, pookie, pookie
Ferme la porte, t'as la pookie dans l'sas
Ah, depuis longtemps, j'ai vu dans ça depuis longtemps
J'ai vu dans ça depuis longtemps, ah, ah, j'ai vu dans ça
Bye bye, j'ai pas besoin d'bails, bails
J't'ai barré fort, là j'ai pas l'time pour toi
J't'ai barré fort, là tu fais trop d'efforts
Ces bails-là, c'est pour les mecs comme toi
Tacler pour des pépètes, ça va claquer
Pour des pipelettes, ça va claquer, crac
Pour les bons bails, ça va grave quer-cra
J'crois qu'c'est l'heure, ding dong
J'suis gang, hors game
Boy ne joue pas, bang bang bang
J'suis gang, hors game
Boy ne joue pas, bang bang bang
Blah blah blah d'la pookie
Ferme la porte, t'as la pookie dans l'side
Blah blah blah d'la pookie
Ferme la porte, t'as la pookie dans l'sas
Ah, depuis longtemps, j'ai vu dans ça depuis longtemps
J'ai vu dans ça depuis longtemps, ah, ah, j'ai vu dans ça
Bébé fait du sale, allô allô allô
Million d'dollars, bébé tu vaux ça
Bébé fait du sale, allô allô allô
Million d'dollars, bébé tu vaux ça
Oh c'est chaud là-haut, oh c'est chaud là
Oh c'est chaud là-haut, oh c'est chaud là
Ah, depuis longtemps, j'ai vu dans ça depuis longtemps
J'ai vu dans ça depuis longtemps, ah, ah, j'ai vu dans ça
Ah, depuis longtemps, j'ai vu dans ça depuis longtemps
J'ai vu dans ça depuis longtemps, ah, ah, j'ai vu dans ça


""",
    "depends" : [
        "account",
        "crm",
        "base_iban",
        "base_vat",
    ],
    "data" : [
        'data/res.country.state.csv',
    ],
}